public void verificarAcesso(boolean usuarioAtivo,
                            boolean senhaCorreta,
                            boolean administrador,
                            boolean bloqueado,
                            boolean acessoInterno) {

    boolean usuarioComumValido = usuarioAtivo && senhaCorreta && !bloqueado;
    boolean administradorValido = administrador && senhaCorreta && acessoInterno;
    boolean podeAcessar = usuarioComumValido || administradorValido;

    if (podeAcessar) {
        System.out.println("Acesso permitido");
    } else {
        System.out.println("Acesso negado");
    }

    return podeAcessar;
}