import java.util.ArrayList;

public void finalizarPedido(String cliente, int quantidade, double precoUnitario, boolean cupomAplicado) {
    double subtotal = quantidade * precoUnitario;
    double desconto = calcularDesconto(cupomAplicado, subtotal);
    double total = subtotal - desconto;

    imprimirResumo(cliente, quantidade, precoUnitario, subtotal, desconto, total);

    verificarFreteGratis(total);
}

public double calcularDesconto(Boolean cupomAplicado, double subtotal){
    if (cupomAplicado) {
        return subtotal * 0.15;
    }
    return 0;
}

public void imprimirResumo(String cliente,
                           int quantidade,
                           double precoUnitario,
                           double subtotal,
                           double desconto,
                           double total){
    System.out.println("Cliente: " + cliente);
    System.out.println("Quantidade: " + quantidade);
    System.out.println("Preço unitário: R$ " + precoUnitario);
    System.out.println("Subtotal: R$ " + subtotal);
    System.out.println("Desconto: R$ " + desconto);
    System.out.println("Total: R$ " + total);
}

public void verificarFreteGratis(double total){
    if (total >= 100) {
        System.out.println("Pedido com frete grátis");
    } else {
        System.out.println("Pedido com frete pago");
    }
}