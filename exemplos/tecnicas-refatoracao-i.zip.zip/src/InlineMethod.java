public void liberarCertificado(double notaFinal) {
    if (notaFinal >= 6.0) {
        System.out.println("Certificado liberado");
    } else {
        System.out.println("Certificado não liberado");
    }
}