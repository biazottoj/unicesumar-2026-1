public void verificarDesconto(double totalCompra) {
    if (totalCompra >= 200) {
        System.out.println("Desconto aplicado");
    } else {
        System.out.println("Sem desconto");
    }
}