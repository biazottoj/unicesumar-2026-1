package br.edu.refactoring.classes.introducelocalextension;

import java.time.DayOfWeek;
import java.time.LocalDate;

public class GeradorBoletoBefore {

    public void gerarBoleto(String cliente, LocalDate dataVencimento) {
        System.out.println("Cliente: " + cliente);

        String dataFormatada = dataVencimento.getDayOfMonth() + "/"
                + dataVencimento.getMonthValue() + "/"
                + dataVencimento.getYear();

        System.out.println("Vencimento: " + dataFormatada);

        if (dataVencimento.getDayOfWeek() == DayOfWeek.SATURDAY
                || dataVencimento.getDayOfWeek() == DayOfWeek.SUNDAY) {
            System.out.println("Atenção: vencimento em final de semana");
        } else {
            System.out.println("Vencimento em dia útil");
        }
    }
}
