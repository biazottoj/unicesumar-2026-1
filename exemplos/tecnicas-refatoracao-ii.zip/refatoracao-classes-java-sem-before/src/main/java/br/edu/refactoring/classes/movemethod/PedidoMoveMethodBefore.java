package br.edu.refactoring.classes.movemethod;

public class PedidoMoveMethodBefore {

    private double valorTotal;

    public PedidoMoveMethodBefore(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public double calcularDescontoCliente(ClienteMoveMethodBefore cliente) {
        if (cliente.isVip()) {
            return cliente.getTotalComprasAnteriores() * 0.05;
        }

        if (cliente.getTotalComprasAnteriores() > 1000) {
            return cliente.getTotalComprasAnteriores() * 0.03;
        }

        return 0;
    }

    public double getValorTotal() {
        return valorTotal;
    }
}
