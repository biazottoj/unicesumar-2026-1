package br.edu.refactoring.classes;

import java.time.LocalDate;

import br.edu.refactoring.classes.introducelocalextension.GeradorBoletoBefore;

import br.edu.refactoring.classes.movemethod.ClienteMoveMethodBefore;
import br.edu.refactoring.classes.movemethod.PedidoMoveMethodBefore;

import br.edu.refactoring.classes.movefield.ProdutoMoveFieldBefore;
import br.edu.refactoring.classes.movefield.PedidoMoveFieldBefore;

import br.edu.refactoring.classes.extractclass.AlunoExtractClassBefore;

public class Main {

    public static void main(String[] args) {
        executarIntroduceLocalExtension();
        executarMoveMethod();
        executarMoveField();
        executarExtractClass();
    }

    private static void executarIntroduceLocalExtension() {
        System.out.println("==================================================");
        System.out.println("1. Introduce Local Extension — antes da refatoração");
        System.out.println("==================================================");

        LocalDate dataVencimento = LocalDate.of(2026, 5, 16);
        new GeradorBoletoBefore().gerarBoleto("Maria", dataVencimento);
    }

    private static void executarMoveMethod() {
        System.out.println("\n==================================================");
        System.out.println("2. Move Method — antes da refatoração");
        System.out.println("==================================================");

        ClienteMoveMethodBefore cliente = new ClienteMoveMethodBefore(true, 2000.0);
        PedidoMoveMethodBefore pedido = new PedidoMoveMethodBefore(500.0);

        System.out.println("Valor total: R$ " + pedido.getValorTotal());
        System.out.println("Desconto: R$ " + pedido.calcularDescontoCliente(cliente));
    }

    private static void executarMoveField() {
        System.out.println("\n==================================================");
        System.out.println("3. Move Field — antes da refatoração");
        System.out.println("==================================================");

        ProdutoMoveFieldBefore produto = new ProdutoMoveFieldBefore("Livro", 80.0, "87000-000");
        PedidoMoveFieldBefore pedido = new PedidoMoveFieldBefore(produto, 2);

        pedido.imprimirResumo();
    }

    private static void executarExtractClass() {
        System.out.println("\n==================================================");
        System.out.println("4. Extract Class — antes da refatoração");
        System.out.println("==================================================");

        AlunoExtractClassBefore aluno = new AlunoExtractClassBefore(
                "João", "2026001", "Rua das Flores", "100",
                "Centro", "Maringá", "PR", "87000-000");

        aluno.imprimirDados();
        System.out.println("Endereço completo: " + aluno.getEnderecoCompleto());
    }
}
