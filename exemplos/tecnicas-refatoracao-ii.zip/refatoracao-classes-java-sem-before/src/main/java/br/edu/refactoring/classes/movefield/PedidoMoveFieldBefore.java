package br.edu.refactoring.classes.movefield;

public class PedidoMoveFieldBefore {

    private ProdutoMoveFieldBefore produto;
    private int quantidade;

    public PedidoMoveFieldBefore(ProdutoMoveFieldBefore produto, int quantidade) {
        this.produto = produto;
        this.quantidade = quantidade;
    }

    public void imprimirResumo() {
        System.out.println("Produto: " + produto.getNome());
        System.out.println("Quantidade: " + quantidade);
        System.out.println("CEP de entrega: " + produto.getCepEntrega());
    }
}
