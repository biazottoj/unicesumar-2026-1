package br.edu.refactoring.classes.movefield;

public class ProdutoMoveFieldBefore {

    private String nome;
    private double preco;
    private String cepEntrega;

    public ProdutoMoveFieldBefore(String nome, double preco, String cepEntrega) {
        this.nome = nome;
        this.preco = preco;
        this.cepEntrega = cepEntrega;
    }

    public String getCepEntrega() {
        return cepEntrega;
    }

    public double getPreco() {
        return preco;
    }

    public String getNome() {
        return nome;
    }
}
