package br.edu.refactoring.classes.movemethod;

public class ClienteMoveMethodBefore {

    private boolean vip;
    private double totalComprasAnteriores;

    public ClienteMoveMethodBefore(boolean vip, double totalComprasAnteriores) {
        this.vip = vip;
        this.totalComprasAnteriores = totalComprasAnteriores;
    }

    public boolean isVip() {
        return vip;
    }

    public double getTotalComprasAnteriores() {
        return totalComprasAnteriores;
    }
}
