package br.edu.refactoring.classes.extractclass;

public class AlunoExtractClassBefore {

    private String nome;
    private String ra;

    private String rua;
    private String numero;
    private String bairro;
    private String cidade;
    private String estado;
    private String cep;

    public AlunoExtractClassBefore(String nome, String ra, String rua, String numero,
                                   String bairro, String cidade, String estado, String cep) {
        this.nome = nome;
        this.ra = ra;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.cep = cep;
    }

    public void imprimirDados() {
        System.out.println("Aluno: " + nome);
        System.out.println("RA: " + ra);
        System.out.println("Endereço: " + rua + ", " + numero + " - " + bairro);
        System.out.println("Cidade: " + cidade + " - " + estado);
        System.out.println("CEP: " + cep);
    }

    public String getEnderecoCompleto() {
        return rua + ", " + numero + " - " + bairro + ", "
                + cidade + " - " + estado + ", " + cep;
    }
}
