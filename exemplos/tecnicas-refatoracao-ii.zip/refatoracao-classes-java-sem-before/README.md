# Projeto Java — Refatoração entre classes

Este projeto contém apenas as classes **antes da refatoração** para que os alunos possam aplicar as seguintes técnicas:

1. Introduce Local Extension
2. Move Method
3. Move Field
4. Extract Class

As classes foram colocadas diretamente dentro da pasta de cada técnica, sem a subpasta `before`.

## Estrutura do projeto

```text
src/main/java/br/edu/refactoring/classes/
├── Main.java
├── introducelocalextension/
│   └── GeradorBoletoBefore.java
├── movemethod/
│   ├── ClienteMoveMethodBefore.java
│   └── PedidoMoveMethodBefore.java
├── movefield/
│   ├── ProdutoMoveFieldBefore.java
│   └── PedidoMoveFieldBefore.java
└── extractclass/
    └── AlunoExtractClassBefore.java
```

## Como executar

Na pasta do projeto, execute:

```bash
mvn compile exec:java
```

Também é possível abrir o projeto em uma IDE e executar a classe:

```text
br.edu.refactoring.classes.Main
```

## Objetivo da atividade

Os alunos devem refatorar o projeto aplicando as técnicas indicadas.

Para cada pacote:

- `introducelocalextension`: aplicar **Introduce Local Extension**;
- `movemethod`: aplicar **Move Method**;
- `movefield`: aplicar **Move Field**;
- `extractclass`: aplicar **Extract Class**.

O comportamento externo do programa deve permanecer equivalente após a refatoração.
