package strategy;

public class CalculadoraFrete {

    public double calcularFrete(Pedido pedido) {
        if (pedido.getTipoEntrega().equals("CORREIOS")) {
            return 10.0 + pedido.getPeso() * 2.5;
        }

        if (pedido.getTipoEntrega().equals("TRANSPORTADORA")) {
            if (pedido.getValor() > 500.0) {
                return 0.0;
            }
            return 30.0 + pedido.getPeso() * 1.8;
        }

        if (pedido.getTipoEntrega().equals("EXPRESSA")) {
            return 50.0 + pedido.getPeso() * 4.0;
        }

        if (pedido.getTipoEntrega().equals("RETIRADA_LOJA")) {
            return 0.0;
        }

        throw new IllegalArgumentException("Tipo de entrega inválido");
    }
}
