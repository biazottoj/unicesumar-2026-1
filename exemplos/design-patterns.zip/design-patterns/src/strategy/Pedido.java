package strategy;

public class Pedido {
    private double valor;
    private double peso;
    private String tipoEntrega;

    public Pedido(double valor, double peso, String tipoEntrega) {
        this.valor = valor;
        this.peso = peso;
        this.tipoEntrega = tipoEntrega;
    }

    public double getValor() {
        return valor;
    }

    public double getPeso() {
        return peso;
    }

    public String getTipoEntrega() {
        return tipoEntrega;
    }
}