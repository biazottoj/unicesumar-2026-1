package strategy;

public class Main {
    public static void main(String[] args) {
        Pedido pedido1 = new Pedido(300.0, 4.0, "CORREIOS");
        Pedido pedido2 = new Pedido(800.0, 8.0, "TRANSPORTADORA");
        Pedido pedido3 = new Pedido(120.0, 2.0, "EXPRESSA");

        CalculadoraFrete calculadora = new CalculadoraFrete();

        System.out.println("Frete pedido 1: " + calculadora.calcularFrete(pedido1));
        System.out.println("Frete pedido 2: " + calculadora.calcularFrete(pedido2));
        System.out.println("Frete pedido 3: " + calculadora.calcularFrete(pedido3));
    }
}
