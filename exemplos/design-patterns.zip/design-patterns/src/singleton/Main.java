package singleton;

public class Main {
    public static void main(String[] args) {
        ServicoPedido servicoPedido = new ServicoPedido();
        ServicoPagamento servicoPagamento = new ServicoPagamento();
        ServicoEntrega servicoEntrega = new ServicoEntrega();

        servicoPedido.criarPedido("Ana", 250.0);
        servicoPagamento.processarPagamento(250.0, "PIX");
        servicoEntrega.despacharPedido("PED-001");
    }
}
