package singleton;

public class ServicoEntrega {

    public void despacharPedido(String codigoPedido) {
        LoggerSistema logger = LoggerSistema.getInstance();

        logger.log("Preparando despacho do pedido: " + codigoPedido);

        if (codigoPedido == null || codigoPedido.isBlank()) {
            logger.log("Erro: código do pedido inválido");
            return;
        }

        logger.log("Pedido " + codigoPedido + " despachado com sucesso");
    }
}
