package singleton;

public class ServicoPagamento {

    public void processarPagamento(double valor, String formaPagamento) {
        LoggerSistema logger = LoggerSistema.getInstance();

        logger.log("Iniciando pagamento via " + formaPagamento);

        if (valor <= 0) {
            logger.log("Erro: valor do pagamento inválido");
            return;
        }

        logger.log("Pagamento aprovado no valor de R$ " + valor);
    }
}
