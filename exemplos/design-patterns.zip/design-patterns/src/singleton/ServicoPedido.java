package singleton;

public class ServicoPedido {

    public void criarPedido(String cliente, double valor) {
        LoggerSistema logger = LoggerSistema.getInstance();

        logger.log("Iniciando criação do pedido para o cliente: " + cliente);

        if (valor <= 0) {
            logger.log("Erro: valor do pedido inválido");
            return;
        }

        logger.log("Pedido criado com sucesso no valor de R$ " + valor);
    }
}