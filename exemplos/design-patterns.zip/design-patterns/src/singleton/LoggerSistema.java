package singleton;

import java.time.LocalDateTime;

public final class LoggerSistema {

    private static LoggerSistema instance;

    private LoggerSistema() {
    }

    public static LoggerSistema getInstance() {
        if (instance == null){
            instance = new LoggerSistema();
        }
        return instance;
    }

    public void log(String mensagem) {
        System.out.println(LocalDateTime.now() + " - " + mensagem);
    }
}
