public void finalizarCompra(Cliente cliente, Carrinho carrinho) {

    Double total = calcularTotal(carrinho) * getPorcentagemDesconto(cliente);

    Pedido pedido = new Pedido(cliente, carrinho.getItens(), total));

    pedidoRepository.salvar(pedido);

    notificarCliente(cliente, total);
}

public Double calcularTotal(Carrinho carrinho){
    double total = 0;

    for (Item item : carrinho.getItens()) {
        total += item.getPreco() * item.getQuantidade();
    }

    return total;
}

public Double getPorcentagemDesconto(Cliente cliente){
    if (cliente.isVip()) {
        return 0.8;
    }
    return 1.0;
}

public void notificarCliente(Cliente cliente, Double total){
    EmailService.enviarEmail(
            cliente.getEmail(),
            "Pedido confirmado",
            "Seu pedido foi confirmado no valor de R$ " + total
    );
}


