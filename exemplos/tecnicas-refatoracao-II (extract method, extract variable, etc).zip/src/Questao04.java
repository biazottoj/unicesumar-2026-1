public boolean validarSenha(String login, String senha) {
    Usuario usuario = usuarioRepository.buscarPorLogin(login);
    if (usuario == null) {
        return false;
    }
    if (usuario.getSenha().equals(senha)) {
        Sessao.iniciar(usuario);
        return true;
    }
    return false;
}


// ---------------------------

public boolean validarSenhaEIniciarSessao(String login, String senha) {
    Usuario usuario = usuarioRepository.buscarPorLogin(login);
    if (usuario == null) {
        return false;
    }
    if (usuario.getSenha().equals(senha)) {
        Sessao.iniciar(usuario);
        return true;
    }
    return false;
}

// ---------------------------

public boolean validarSenha(Usuario usuario, String senha) {
    if (usuario.getSenha().equals(senha)) {
        return true;
    }
    return false;
}

public Boolean iniciarSessao(String login, String senha) {
    Usuario usuario = usuarioRepository.buscarPorLogin(login);

    if (usuario == null) {
        return false;
    }

    if(!validarSenha(usuario, senha)){
        return false;
    }

    Sessao.iniciar(usuario);

    return true;

}

