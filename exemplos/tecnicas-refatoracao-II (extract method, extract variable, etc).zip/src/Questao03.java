public Aluno(...){}

public void cadastrarAluno(Aluno aluno) {
    alunoRepository.salvar(aluno);
}