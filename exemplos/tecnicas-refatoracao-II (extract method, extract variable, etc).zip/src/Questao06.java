public boolean podeAcessarSistema(Usuario usuario) {

    if(usuario == null){
        return false;
    }

    if(!usuario.isAtivo()){
        return false;
    }

    if(usuario.isBloqueado()){
        return false;
    }

    if(!usuario.temPermissao("SISTEMA")){
        return false;
    }

    return true;
}
