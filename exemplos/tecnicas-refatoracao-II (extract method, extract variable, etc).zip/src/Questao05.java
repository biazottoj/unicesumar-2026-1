public double calcularPrecoComDesconto(Produto produto) {
    return produto.getPreco() * getPorcentagemDesconto(produto);
}

public Boolean isElegivelDesconto(Produto produto){
    return produto.getCategoria().equals("LIVRO") ||
            produto.getCategoria().equals("ELETRONICO") ||
            produto.getCategoria().equals("ROUPA");
}

public Double getPorcentagemDesconto(Produto produto){

    if(isElegivelDesconto(produto)){
        return 0.9;
    }

    return 1.0;
}


// ---------------------

public Double getPorcentagemDesconto(Produto produto){

    // Descricao = Livro; Desconto = 0.8;
    // Livro: Extraordinário


    Categoria categoria = categoriaRepository.getCategoriaPorDescricao(produto.getCategoria());

    return categoria.getDesconto();
}