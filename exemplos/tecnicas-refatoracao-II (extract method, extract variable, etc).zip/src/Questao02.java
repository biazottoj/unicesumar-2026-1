public boolean usuarioPodeAcessarSistema(Usuario usuario) {
    return usuario.getIdade() >= 18 && usuario.isAtivo();
}