# Atividade — Refatoração em um Sistema de Estacionamento

## Contexto

O projeto representa um pequeno sistema de estacionamento. Ele possui classes para representar clientes, veículos, vagas, tickets, reservas e pagamentos.

O sistema compila e executa, mas algumas responsabilidades estão mal distribuídas. A tarefa é melhorar a organização do código por meio de refatorações.

## Regras

1. Execute o projeto antes de modificar o código.
2. Observe a saída produzida pela classe `Main`.
3. Aplique as refatorações indicadas nos exercícios.
4. Execute o projeto novamente.
5. O comportamento geral deve ser preservado.
6. Não altere regras de negócio sem necessidade.
7. Crie novas classes quando a técnica exigir.
8. Renomeie métodos e atributos quando isso ajudar a clareza.

---

# Exercício 1 — Introduce Local Extension para data e hora

## Classes relacionadas

- `TicketEstacionamento`
- possivelmente uma nova classe para encapsular `LocalDateTime`

## Problema

A classe `TicketEstacionamento` manipula diretamente `LocalDateTime` para:

- formatar a data e hora de entrada;
- verificar se a entrada ocorreu em horário especial.

Essas regras podem aparecer em outras partes do sistema e não pertencem necessariamente ao ticket.

## Tarefa

Crie uma extensão local para representar uma data e hora usada no estacionamento.

Essa nova classe pode encapsular `LocalDateTime` e oferecer operações como:

- formatar data e hora;
- verificar se está em horário especial;
- retornar o valor original, se necessário.

## Reflexão

- Por que não alterar diretamente `LocalDateTime`?
- Que comportamentos fazem sentido para uma data e hora dentro do domínio do estacionamento?
- A nova classe deixa `TicketEstacionamento` mais simples?

---

# Exercício 2 — Introduce Local Extension para valor monetário

## Classes relacionadas

- `RegistroPagamento`
- possivelmente uma nova classe para encapsular `BigDecimal`

## Problema

A classe `RegistroPagamento` manipula diretamente `BigDecimal` para:

- formatar valor em reais;
- comparar se o pagamento é de alto valor.

Essas regras são específicas do domínio financeiro do sistema.

## Tarefa

Crie uma extensão local para representar valores monetários do estacionamento.

Essa nova classe pode encapsular `BigDecimal` e oferecer operações como:

- formatar em reais;
- verificar se o valor é alto;
- retornar o valor original, se necessário.

## Reflexão

- O que é mais expressivo: `BigDecimal` ou uma classe do domínio, como `ValorMonetario`?
- Essa refatoração ajuda a evitar repetição de formatação monetária?
- A classe `RegistroPagamento` fica mais focada em registrar o pagamento?

---

# Exercício 3 — Move Method: permanência do ticket

## Classes relacionadas

- `OperacaoEstacionamento`
- `TicketEstacionamento`

## Problema

O método `calcularMinutosPermanencia` está em `OperacaoEstacionamento`, mas usa dados do ticket.

## Tarefa

Avalie se o método deve ser movido para `TicketEstacionamento`.

Depois da refatoração, a classe que representa o ticket deve saber calcular sua própria permanência.

## Reflexão

- O método usa mais dados de qual classe?
- O nome do método continua fazendo sentido depois de movido?
- `OperacaoEstacionamento` ainda é necessária para essa responsabilidade?

---

# Exercício 4 — Move Method: desconto do cliente

## Classes relacionadas

- `CentralClientes`
- `Cliente`

## Problema

O método `calcularDescontoCliente` está em `CentralClientes`, mas usa principalmente dados de `Cliente`.

## Tarefa

Mova a regra de desconto para a classe que possui os dados necessários.

## Reflexão

- O desconto é uma característica derivada do cliente?
- `CentralClientes` deveria conhecer os detalhes dos pontos de fidelidade?
- Quais getters deixam de ser necessários após a movimentação?

---

# Exercício 5 — Move Method: status da vaga

## Classes relacionadas

- `PainelVagas`
- `Vaga`

## Problema

O método `descreverStatus` está em `PainelVagas`, mas usa apenas dados de `Vaga`.

## Tarefa

Mova a responsabilidade de descrever o status para `Vaga`.

## Reflexão

- A vaga pode saber descrever seu próprio estado?
- O painel deveria calcular o status ou apenas exibi-lo?
- A refatoração melhora a coesão da classe `Vaga`?

---

# Exercício 6 — Move Field: datas de entrada e saída

## Classes relacionadas

- `Veiculo`
- `TicketEstacionamento`

## Problema

A classe `Veiculo` armazena `dataHoraEntrada` e `dataHoraSaidaPrevista`.

Essas datas não descrevem o veículo em si. Elas descrevem uma permanência específica no estacionamento.

## Tarefa

Mova esses campos para `TicketEstacionamento`.

Ajuste construtores, getters e chamadas afetadas.

## Reflexão

- O mesmo veículo poderia entrar no estacionamento várias vezes em dias diferentes?
- As datas pertencem ao veículo ou ao ticket?
- Que classe deveria fornecer a permanência do veículo no estacionamento?

---

# Exercício 7 — Move Field: dados da reserva

## Classes relacionadas

- `Vaga`
- `ReservaVaga`

## Problema

A classe `Vaga` possui `nomeClienteReserva` e `horarioReserva`.

Esses dados não descrevem a vaga de forma permanente. Eles descrevem uma reserva específica.

## Tarefa

Mova esses campos para `ReservaVaga`.

Ajuste construtores, getters e métodos de impressão.

## Reflexão

- Uma mesma vaga pode ter diferentes reservas em dias diferentes?
- O nome do cliente reservado pertence à vaga ou à reserva?
- A classe `Vaga` fica mais simples após a mudança?

---

# Exercício 8 — Extract Class: endereço do estacionamento

## Classe relacionada

- `Estacionamento`

## Problema

A classe `Estacionamento` mistura dados do estacionamento com dados de endereço.

Os campos `rua`, `numero`, `bairro`, `cidade`, `estado` e `cep` formam um conceito separado.

## Tarefa

Extraia uma classe para representar o endereço.

## Reflexão

- Quais atributos devem ir para a nova classe?
- O método `getEnderecoCompleto` deve permanecer em `Estacionamento`?
- A nova classe poderia ser reutilizada em outras partes do sistema?

---

# Exercício 9 — Extract Class: dados de cobrança do cliente

## Classe relacionada

- `Cliente`

## Problema

A classe `Cliente` mistura dados pessoais, dados de fidelidade e dados de cobrança.

Os campos `banco`, `agencia`, `conta` e `metodoPagamentoPreferencial` formam um conceito separado.

## Tarefa

Extraia uma classe para representar os dados de cobrança.

## Reflexão

- A cobrança é um conceito próprio no domínio?
- O método `getDadosCobrancaFormatados` deveria ser movido?
- A classe `Cliente` fica mais focada após a extração?

---

# Exercício 10 — Extract Class: dados do seguro do veículo

## Classe relacionada

- `Veiculo`

## Problema

A classe `Veiculo` mistura dados do veículo com dados de seguro.

Os campos `seguradora`, `numeroApolice` e `telefoneAssistencia` formam um conceito separado.

## Tarefa

Extraia uma classe para representar os dados do seguro.

## Reflexão

- O seguro é um conceito separado do veículo?
- O método `getDadosSeguroFormatados` deveria ser movido?
- Como essa extração afeta a leitura da classe `Veiculo`?

---

# Entrega sugerida

Entregue o projeto refatorado e um pequeno texto respondendo:

1. Quais classes novas foram criadas?
2. Quais métodos foram movidos?
3. Quais atributos foram movidos?
4. Qual refatoração deixou o código mais claro?
5. Houve alguma refatoração que exigiu mudanças em várias classes? Por quê?
