public class StreamingService {
    private LocacaoRepository repo;
    private PagamentoGateway pagamentoGateway;
    private NotificadorEmail emailService;

    public StreamingService(LocacaoRepository repo,
                            PagamentoGateway pagamentoGateway,
                            NotificadorEmail emailService) {
        this.repo = repo;
        this.pagamentoGateway = pagamentoGateway;
        this.emailService = emailService;
    }

    public String processarLocacao(Usuario usuario,
                                   Filme filme,
                                   boolean cupomDesconto,
                                   boolean estreiaDaSemana,
                                   boolean perfilValidado) {

        if (usuario != null) {
            if (filme != null) {
                if (!repo.jaLocado(usuario.getId(), filme.getCodigo())) {
                    if (filme.temLicencasDisponiveis()) {
                        if (perfilValidado) {
                            double valor = filme.getPrecoBase();

                            if (cupomDesconto) {
                                valor = valor * 0.7;
                            }

                            if (estreiaDaSemana) {
                                valor = valor + 12;
                            }

                            if (usuario.isAdimplente()) {
                                if (pagamentoGateway.cobrar(usuario, valor)) {
                                    Locacao locacao =
                                            new Locacao(usuario, filme, valor, true);

                                    repo.salvar(locacao);
                                    emailService.enviarConfirmacao(usuario, filme);
                                    filme.reduzirLicenca();

                                    return "Locação concluída";
                                } else {
                                    return "Pagamento recusado";
                                }
                            } else {
                                return "Usuário inadimplente";
                            }
                        } else {
                            return "Perfil não validado";
                        }
                    } else {
                        return "Filme indisponível";
                    }
                } else {
                    return "Filme já locado pelo usuário";
                }
            } else {
                return "Filme inválido";
            }
        } else {
            return "Usuário inválido";
        }
    }
}
